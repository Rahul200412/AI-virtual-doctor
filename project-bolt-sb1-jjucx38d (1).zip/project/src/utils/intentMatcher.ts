interface Intent {
  tag: string;
  patterns: string[];
  responses: string[];
}

const calculateSimilarity = (str1: string, str2: string): number => {
  const s1 = str1.toLowerCase();
  const s2 = str2.toLowerCase();

  if (s1 === s2) return 1.0;
  if (s1.includes(s2) || s2.includes(s1)) return 0.8;

  const words1 = s1.split(/\s+/);
  const words2 = s2.split(/\s+/);

  let matchCount = 0;
  for (const word1 of words1) {
    for (const word2 of words2) {
      if (word1 === word2 || word1.includes(word2) || word2.includes(word1)) {
        matchCount++;
        break;
      }
    }
  }

  const similarity = matchCount / Math.max(words1.length, words2.length);
  return similarity;
};

export const findBestIntent = (userMessage: string, intents: Intent[]): Intent | null => {
  let bestMatch: Intent | null = null;
  let highestScore = 0;
  const threshold = 0.3;

  for (const intent of intents) {
    for (const pattern of intent.patterns) {
      const score = calculateSimilarity(userMessage, pattern);

      if (score > highestScore && score >= threshold) {
        highestScore = score;
        bestMatch = intent;
      }
    }
  }

  return bestMatch;
};

export const getRandomResponse = (responses: string[]): string => {
  const response = responses[Math.floor(Math.random() * responses.length)];
  // Replace both \\n (escaped) and \n (literal) with actual newlines
  return response.replace(/\\\\n/g, '\n').replace(/\\n/g, '\n');
};
