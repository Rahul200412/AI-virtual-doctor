export const getSessionId = (): string => {
  let sessionId = sessionStorage.getItem('dr_atlas_session');

  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    sessionStorage.setItem('dr_atlas_session', sessionId);
  }

  return sessionId;
};

export const clearSession = (): void => {
  sessionStorage.removeItem('dr_atlas_session');
};
