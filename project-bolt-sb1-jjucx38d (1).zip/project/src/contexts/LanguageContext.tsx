import { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'te';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    appTitle: "Dr. Atlas - Medical Assistant",
    welcomeMessage: "Hello! I'm Dr. Atlas, your medical assistant. How can I help you today?",
    disclaimer: "This is for informational purposes only. Not a substitute for professional medical advice.",
    emergency: "Medical Emergency? Call 911 immediately",
    typeMessage: "Type your message...",
    send: "Send",
    symptoms: "Describe Symptoms",
    medications: "Check Medications",
    prevention: "Prevention Tips",
    firstAid: "First Aid Help",
    findDoctor: "Find a Doctor",
    mentalHealth: "Mental Health",
    selectLanguage: "Language",
    thinking: "Dr. Atlas is thinking...",
    error: "Sorry, I encountered an error. Please try again.",
  },
  te: {
    appTitle: "డాక్టర్ అట్లాస్ - వైద్య సహాయకుడు",
    welcomeMessage: "నమస్కారం! నేను డాక్టర్ అట్లాస్, మీ వైద్య సహాయకుడిని. ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?",
    disclaimer: "ఇది సమాచార ప్రయోజనాల కోసం మాత్రమే. వృత్తిపరమైన వైద్య సలహాకు ప్రత్యామ్నాయం కాదు.",
    emergency: "వైద్య అత్యవసరమా? వెంటనే 108 కు కాల్ చేయండి",
    typeMessage: "మీ సందేశాన్ని టైప్ చేయండి...",
    send: "పంపించు",
    symptoms: "లక్షణాలు వివరించండి",
    medications: "మందులు తనిఖీ చేయండి",
    prevention: "నివారణ చిట్కాలు",
    firstAid: "ప్రథమ చికిత్స సహాయం",
    findDoctor: "వైద్యుడిని కనుగొనండి",
    mentalHealth: "మానసిక ఆరోగ్యం",
    selectLanguage: "భాష",
    thinking: "డాక్టర్ అట్లాస్ ఆలోచిస్తున్నారు...",
    error: "క్షమించండి, నాకు లోపం ఎదురైంది. దయచేసి మళ్లీ ప్రయత్నించండి.",
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
