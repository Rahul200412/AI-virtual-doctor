import { useState, useEffect, useRef } from 'react';
import { Message } from '../types';
import { supabase } from '../lib/supabase';
import { getSessionId } from '../utils/sessionManager';
import { findBestIntent, getRandomResponse } from '../utils/intentMatcher';

const EMERGENCY_KEYWORDS = [
  'chest pain',
  'heart attack',
  'stroke',
  'can\'t breathe',
  'cannot breathe',
  'severe bleeding',
  'unconscious',
  'suicide',
  'overdose',
  'severe burn',
  'seizure',
];

const detectEmergency = (text: string): boolean => {
  const lowerText = text.toLowerCase();
  return EMERGENCY_KEYWORDS.some(keyword => lowerText.includes(keyword));
};

const generateDoctorResponse = async (userMessage: string, conversationHistory: Message[], language: string = 'en'): Promise<string> => {
  const lowerMessage = userMessage.toLowerCase();

  if (detectEmergency(userMessage)) {
    if (language === 'te') {
      return `ఇది అత్యవసరమని నేను అర్థం చేసుకుంటున్నాను. మీరు వివరించిన దాని ఆధారంగా, ఇది వైద్య అత్యవసరం కావచ్చు.

🚨 దయచేసి వెంటనే 108కు కాల్ చేయండి లేదా మీ సమీపంలోని అత్యవసర గదికి వెళ్లండి.

సహాయం కోసం వేచి ఉన్నప్పుడు:
• ప్రశాంతంగా ఉండండి మరియు నిశ్చలంగా ఉండటానికి ప్రయత్నించండి
• మీతో ఎవరైనా ఉంటే, వారిని మీతో ఉండేలా చేయండి
• ఏదీ తినకండి లేదా త్రాగకండి
• మీ ఫోన్‌ను దగ్గరగా ఉంచుకోండి

⚠️ వైద్య నిరాకరణ: నేను వర్చువల్ అసిస్టెంట్‌ని మరియు ధృవీకరించబడిన వైద్యునికి ప్రత్యామ్నాయం కాను.`;
    }
    return `I understand this is urgent. Based on what you've described, this could be a medical emergency.

🚨 PLEASE CALL 911 IMMEDIATELY or go to your nearest emergency room.

While waiting for help:
• Stay calm and try to remain still
• If someone is with you, have them stay with you
• Don't eat or drink anything
• Keep your phone nearby

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  const { data: intents, error } = await supabase
    .from('intents')
    .select('tag, patterns, responses');

  if (!error && intents && intents.length > 0) {
    const bestIntent = findBestIntent(userMessage, intents);

    if (bestIntent) {
      return getRandomResponse(bestIntent.responses);
    }
  }

  if (lowerMessage.includes('hello') || lowerMessage.includes('hi ') || lowerMessage === 'hi' || lowerMessage.includes('hey') || lowerMessage.includes('నమస్కారం') || lowerMessage.includes('హలో')) {
    if (language === 'te') {
      return `నమస్కారం! నేను డాక్టర్ సాయికృష్ణ, మీ స్నేహపూర్వక వర్చువల్ వైద్య సహాయకుడు. మిమ్మల్ని కలవడం చాలా సంతోషంగా ఉంది!

నేను మీకు ఈ విషయాలలో సహాయం చేయడానికి ఇక్కడ ఉన్నాను:
• వైద్య ప్రశ్నలు మరియు ఆరోగ్య సమస్యలు
• లక్షణాలను అర్థం చేసుకోవడం
• ప్రథమ చికిత్స మార్గదర్శకత్వం
• సాధారణ ఆరోగ్య సలహా
• లేదా కేవలం స్నేహపూర్వక సంభాషణ!

ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?`;
    }
    return `Hello! I'm Dr. Saikrishna, your friendly virtual medical assistant. It's great to meet you!

I'm here to help you with:
• Medical questions and health concerns
• Understanding symptoms
• First-aid guidance
• General health advice
• Or just having a friendly conversation!

How can I assist you today?`;
  }

  if (lowerMessage.includes('how are you') || lowerMessage.includes('how r u') || lowerMessage.includes('ఎలా ఉన్నారు')) {
    if (language === 'te') {
      return `నేను చాలా బాగున్నాను, అడిగినందుకు ధన్యవాదాలు! మీకు ఏవైనా ప్రశ్నలు లేదా ఆందోళనలతో సహాయం చేయడానికి నేను ఎల్లప్పుడూ సిద్ధంగా ఉన్నాను.

మీ వర్చువల్ వైద్య సహాయకుడిగా, మార్గదర్శకత్వం అందించడానికి, ప్రశ్నలకు సమాధానం ఇవ్వడానికి లేదా కేవలం చాట్ చేయడానికి నేను 24/7 ఇక్కడ ఉన్నాను. మీరు ఈరోజు ఎలా ఫీల్ అవుతున్నారు? మీ మనసులో ఏదైనా ఉందా?`;
    }
    return `I'm doing wonderfully, thank you for asking! I'm always ready and excited to help you with any questions or concerns you might have.

As your virtual medical assistant, I'm here 24/7 to provide guidance, answer questions, or just chat. How are you feeling today? Is there anything on your mind?`;
  }

  if (lowerMessage.includes('your name') || lowerMessage.includes('who are you') || lowerMessage.includes('మీ పేరు') || lowerMessage.includes('మీరు ఎవరు')) {
    if (language === 'te') {
      return `నేను డాక్టర్ సాయికృష్ణ, మీ వర్చువల్ వైద్య సహాయకుడు! ఆరోగ్య ప్రశ్నలు, వైద్య సమస్యలు మరియు సాధారణ ఆరోగ్య సలహాలతో మీకు సహాయం చేయడానికి నేను ఇక్కడ ఉన్నాను.

నన్ను మీ స్నేహపూర్వక ఆరోగ్య సంరక్షణ సహచరుడిగా భావించండి, వినడానికి మరియు మార్గదర్శకత్వం అందించడానికి ఎల్లప్పుడూ అందుబాటులో ఉంటాను. నేను నిజమైన వైద్యునికి ప్రత్యామ్నాయం కాకపోయినా, లక్షణాలను అర్థం చేసుకోవడంలో, ప్రథమ చికిత్స చిట్కాలు అందించడంలో మరియు మీరు ఎప్పుడు వృత్తిపరమైన వైద్య సంరక్షణను కోరాలో సలహా ఇవ్వడంలో సహాయం చేయగలను.

ఈరోజు నేను మీకు ఏదైనా నిర్దిష్టంగా సహాయం చేయగలనా?`;
    }
    return `I'm Dr. Saikrishna, your virtual medical assistant! I'm here to help you with health questions, medical concerns, and general wellness advice.

Think of me as your friendly healthcare companion who's always available to listen and provide guidance. While I'm not a replacement for a real doctor, I can help you understand symptoms, provide first-aid tips, and advise when you should seek professional medical care.

Is there anything specific I can help you with today?`;
  }

  if (lowerMessage.includes('what can you do') || lowerMessage.includes('what do you do') || lowerMessage.includes('మీరు ఏమి చేయగలరు')) {
    if (language === 'te') {
      return `మంచి ప్రశ్న! నేను మీకు ఈ విషయాలలో సహాయం చేయగలను:

**ఆరోగ్యం & వైద్యం:**
• వైద్య ప్రశ్నలకు సమాధానం ఇవ్వడం
• లక్షణాలు మరియు పరిస్థితులను వివరించడం
• ప్రథమ చికిత్స మార్గదర్శకత్వం అందించడం
• వైద్యుడిని ఎప్పుడు చూడాలో సలహా ఇవ్వడం
• సాధారణ ఆరోగ్య చిట్కాలు అందించడం

**సాధారణ సహాయం:**
• వివిధ అంశాలపై ప్రశ్నలకు సమాధానం ఇవ్వడం
• సమాచారం మరియు వివరణలు అందించడం
• స్నేహపూర్వక సంభాషణలు చేయడం
• మద్దతు మరియు మార్గదర్శకత్వం అందించడం

నేను ఏ విధంగానైనా సహాయకరంగా ఉండటానికి ఇక్కడ ఉన్నాను! మీరు ఏమి తెలుసుకోవాలనుకుంటున్నారు లేదా మాట్లాడాలనుకుంటున్నారు?`;
    }
    return `Great question! Here's what I can help you with:

**Health & Medical:**
• Answer medical questions
• Explain symptoms and conditions
• Provide first-aid guidance
• Advise when to see a doctor
• Offer general wellness tips

**General Assistance:**
• Answer questions on various topics
• Provide information and explanations
• Have friendly conversations
• Offer support and guidance

I'm here to be helpful in any way I can! What would you like to know or talk about?`;
  }

  if (lowerMessage.includes('thank') || lowerMessage.includes('thanks') || lowerMessage.includes('ధన్యవాదాలు')) {
    if (language === 'te') {
      return `మీకు స్వాగతం! నేను సహాయం చేయగలిగినందుకు సంతోషంగా ఉంది. 😊

గుర్తుంచుకోండి, మీకు సహాయం అవసరమైనప్పుడు, అది ఆరోగ్యానికి సంబంధించిన ప్రశ్నలు అయినా లేదా కేవలం చాట్ చేయడం అయినా, నేను ఇక్కడ ఉన్నాను. ఎప్పుడైనా సంప్రదించడానికి సంకోచించకండి!

మీరు తెలుసుకోవాలనుకునే లేదా చర్చించాలనుకునే ఇంకేమైనా ఉందా?`;
    }
    return `You're very welcome! I'm happy I could help. 😊

Remember, I'm here whenever you need assistance, whether it's health-related questions or just someone to chat with. Don't hesitate to reach out anytime!

Is there anything else you'd like to know or discuss?`;
  }

  if (lowerMessage.includes('joke') || lowerMessage.includes('funny')) {
    return `Alright, here's a medical joke for you!

Why did the doctor carry a red pen?

In case they needed to draw blood! 😄

Would you like to hear another one, or is there something else I can help you with today?`;
  }

  if (lowerMessage.includes('weather') || lowerMessage.includes('temperature outside')) {
    return `I appreciate the question! However, I don't have access to real-time weather data. For current weather information, I'd recommend checking a weather app or website.

But I can tell you that staying aware of weather conditions is important for your health! Extreme temperatures can affect your wellbeing, so make sure to dress appropriately and stay hydrated.

Is there anything health-related I can help you with?`;
  }

  if (lowerMessage.includes('chest pain') || lowerMessage.includes('ఛాతీ నొప్పి')) {
    if (language === 'te') {
      return `మీ ఛాతీ నొప్పి గురించి నాకు చెప్పినందుకు ధన్యవాదాలు. ఈ విషయాన్ని నేను చాలా గంభీరంగా తీసుకుంటాను.

మీ పరిస్థితిని బాగా అర్థం చేసుకోవడానికి, దయచేసి నాకు చెప్పండి:

1. ఛాతీ నొప్పి ఎప్పుడు ప్రారంభమైంది?
2. 1-10 స్థాయిలో, నొప్పి ఎంత తీవ్రంగా ఉంది?
3. ఇది పదునైనది, నిస్తేజమైనది, నలిపేస్తున్నది లేదా తగులుతున్నది?
4. ఇది మీ చేయి, తొండ లేదా వెనుకకు వ్యాపిస్తుందా?
5. శ్వాస తీసుకోవడంలో ఇబ్బంది, జిర్పు ఏడడం లేదా వికారం ఏమైనా ఉన్నాయా?

**ముఖ్యమైనది:** మీరు తీవ్రమైన ఛాతీ నొప్పిని అనుభవిస్తున్నట్లయితే, ముఖ్యంగా ఈ ఇతర లక్షణాలతో పాటు, దయచేసి వెంటనే 108కు కాల్ చేయండి. ఇది హృదయాఘాతం కావచ్చు.

⚠️ వైద్య నిరాకరణ: నేను వర్చువల్ అసిస్టెంట్‌ని మరియు ధృవీకరించబడిన వైద్యునికి ప్రత్యామ్నాయం కాను.`;
    }
    return `Thank you for telling me about your chest pain. This is something I take very seriously.

To better understand your situation, please tell me:

1. When did the chest pain start?
2. On a scale of 1-10, how severe is the pain?
3. Is it sharp, dull, crushing, or burning?
4. Does it spread to your arm, jaw, or back?
5. Any shortness of breath, sweating, or nausea?

**Important:** If you're experiencing severe chest pain, especially with these other symptoms, please call 911 immediately. This could be a heart attack.

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  if (lowerMessage.includes('fever') || lowerMessage.includes('temperature') || lowerMessage.includes('జ్వరం')) {
    if (language === 'te') {
      return `మీకు జ్వరం ఉందని నేను అర్థం చేసుకున్నాను. దానితో మీకు సహాయం చేస్తాను.

దయచేసి పంచుకోండి:

1. మీ ప్రస్తుత ఉష్ణోగ్రత ఎంత?
2. జ్వరం ఎప్పుడు ప్రారంభమైంది?
3. ఇతర లక్షణాలు ఏమైనా ఉన్నాయా? (చలి, శరీర నొప్పులు, దగ్గు, గొంతు నొప్పి)
4. మీరు ఏదైనా మందులు తీసుకున్నారా?
5. మీకు ఏదైనా దీర్ఘకాలిక ఆరోగ్య పరిస్థితులు ఉన్నాయా?

**సాధారణ జ్వరం సంరక్షణ చిట్కాలు:**
• హైడ్రేటెడ్‌గా ఉండండి - చాలా ద్రవాలు త్రాగండి
• వీలైనంత ఎక్కువ విశ్రాంతి తీసుకోండి
• తగినట్లయితే జ్వరం తగ్గించే మందులు (అసిటమినోఫెన్ లేదా ఐబుప్రోఫెన్) తీసుకోండి
• మీ ఉష్ణోగ్రతను క్రమం తప్పకుండ పర్యవేక్షించండి

**వైద్యుడిని చూడండి ఒకవేళ:**
• జ్వరం 103°F (39.4°C) కంటే ఎక్కువ ఉంటే
• జ్వరం 3 రోజుల కంటే ఎక్కువ ఉంటే
• మీకు తీవ్రమైన లక్షణాలు ఉంటే

⚠️ వైద్య నిరాకరణ: నేను వర్చువల్ అసిస్టెంట్‌ని మరియు ధృవీకరించబడిన వైద్యునికి ప్రత్యామ్నాయం కాను.`;
    }
    return `I understand you're experiencing a fever. Let me help you with that.

Please share:

1. What is your current temperature?
2. When did the fever start?
3. Any other symptoms? (chills, body aches, cough, sore throat)
4. Have you taken any medication?
5. Do you have any chronic health conditions?

**General Fever Care Tips:**
• Stay hydrated - drink plenty of fluids
• Rest as much as possible
• Take fever-reducing medication (acetaminophen or ibuprofen) if appropriate
• Monitor your temperature regularly

**See a doctor if:**
• Fever above 103°F (39.4°C)
• Fever lasts more than 3 days
• You have severe symptoms

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  if (lowerMessage.includes('headache') || lowerMessage.includes('head hurts')) {
    return `I'm sorry to hear you have a headache. Let me help you understand it better.

Tell me more:

1. Where exactly does your head hurt?
2. How long have you had this headache?
3. Rate the pain from 1-10
4. Is it throbbing, sharp, or dull?
5. Any other symptoms? (nausea, vision changes, sensitivity to light)

**Immediate Relief Tips:**
• Rest in a quiet, dark room
• Apply a cold or warm compress
• Stay hydrated
• Gentle neck and shoulder stretches
• Consider over-the-counter pain relief

**Seek emergency care if:**
• Sudden, severe headache
• Headache with fever, stiff neck, confusion
• After a head injury
• Vision changes or trouble speaking

How long have you been experiencing this headache?

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  if (lowerMessage.includes('cold') || lowerMessage.includes('flu') || lowerMessage.includes('cough') || lowerMessage.includes('sneez')) {
    return `It sounds like you might be dealing with a cold or flu. I'm here to help you feel better!

**Common Cold/Flu Care:**

1. **Rest**: Your body needs energy to fight the infection
2. **Hydration**: Drink plenty of water, herbal tea, or warm liquids
3. **Nutrition**: Eat nutritious foods when you have an appetite
4. **Steam**: Inhaling steam can help with congestion
5. **OTC Medications**: Consider decongestants, cough medicine, or pain relievers

**Symptom Relief:**
• Sore throat: Warm tea with honey, saltwater gargles
• Congestion: Steam inhalation, saline nasal spray
• Cough: Honey (for adults), stay hydrated
• Body aches: Rest and pain relievers

**See a doctor if:**
• Symptoms persist beyond 10 days
• High fever (above 103°F)
• Difficulty breathing
• Severe chest pain
• Symptoms worsen after improving

Which symptoms are bothering you the most?

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  if (lowerMessage.includes('injury') || lowerMessage.includes('hurt') || lowerMessage.includes('pain')) {
    return `I'm here to help with your injury or pain. Let me understand what's happening.

Please tell me:

1. What type of injury or pain is it?
2. When did it happen?
3. How did it occur?
4. Rate the pain from 1-10
5. Can you move the affected area?
6. Any swelling, bruising, or bleeding?

**General First Aid:**
• **R.I.C.E. Method**: Rest, Ice, Compression, Elevation
• Clean any wounds with water
• Apply pressure to stop bleeding
• Don't move the area if you suspect a fracture

**Seek immediate care if:**
• Severe bleeding that won't stop
• Suspected broken bone
• Deep wounds needing stitches
• Severe pain or swelling
• Loss of function in the area

Tell me more about what happened so I can provide better guidance.

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor.`;
  }

  if (lowerMessage.includes('stress') || lowerMessage.includes('anxiety') || lowerMessage.includes('worried')) {
    return `I understand that stress and anxiety can be really challenging. I'm here to support you.

**Quick Stress Relief Techniques:**

1. **Deep Breathing**: Breathe in for 4, hold for 4, out for 4
2. **Grounding Exercise**: Name 5 things you see, 4 you hear, 3 you feel, 2 you smell, 1 you taste
3. **Physical Activity**: Even a short walk can help
4. **Talk to Someone**: Share your feelings with a trusted friend
5. **Limit Caffeine**: It can increase anxiety

**Long-term Strategies:**
• Regular exercise
• Adequate sleep (7-9 hours)
• Healthy diet
• Mindfulness or meditation
• Professional counseling if needed

**Seek professional help if:**
• Anxiety interferes with daily life
• Having panic attacks
• Feeling depressed
• Thoughts of self-harm

Remember, it's okay to not be okay, and seeking help is a sign of strength. Would you like to talk more about what's causing you stress?

⚠️ If you're in crisis, please call 988 (Suicide & Crisis Lifeline) or text "HELLO" to 741741.`;
  }

  if (language === 'te') {
    return `దాన్ని నాతో పంచుకున్నందుకు ధన్యవాదాలు. మీకు అవసరమైన ఏదైనా విషయంలో సహాయం చేయడానికి నేను ఇక్కడ ఉన్నాను!

మీరు నాకు చెప్పిన దాని ఆధారంగా, నేను సరిగ్గా అర్థం చేసుకున్నానని మరియు మీకు ఉత్తమ మార్గదర్శకత్వం అందించాలని నేను నిర్ధారించుకోవాలనుకుంటున్నాను.

మీరు కొంచెం మరింత చెప్పగలరా:
• మీకు నిర్దిష్టంగా ఏ ఆందోళన లేదా ప్రశ్న ఉంది?
• ఇది ఎప్పుడు ప్రారంభమైంది లేదా మీ ప్రశ్నను ప్రేరేపించినది ఏమిటి?
• మీరు నాకు తెలియజేయాలనుకునే ఇంకేమైనా ఉందా?

నేను సహాయం చేయడానికి ఇక్కడ ఉన్నాను దీని గురించి:
• ఆరోగ్యం మరియు వైద్య ప్రశ్నలు
• సాధారణ సమాచారం
• సలహా లేదా మార్గదర్శకత్వం
• లేదా కేవలం స్నేహపూర్వక సంభాషణ

ఇప్పుడు మీకు ఏది అత్యంత సహాయకరంగా ఉంటుంది?

⚠️ వైద్య నిరాకరణ: నేను వర్చువల్ అసిస్టెంట్‌ని మరియు ధృవీకరించబడిన వైద్యునికి ప్రత్యామ్నాయం కాను. తీవ్రమైన వైద్య సమస్యల కోసం, దయచేసి ఆరోగ్య సంరక్షణ నిపుణుడిని సంప్రదించండి.`;
  }

  return `Thank you for sharing that with me. I'm here to help you with whatever you need!

Based on what you've told me, I want to make sure I understand correctly and provide you with the best guidance possible.

Could you tell me a bit more about:
• What specific concern or question do you have?
• When did this start or what prompted your question?
• Is there anything else you'd like me to know?

I'm here to assist whether it's about:
• Health and medical questions
• General information
• Advice or guidance
• Or just friendly conversation

What would be most helpful for you right now?

⚠️ Medical Disclaimer: I'm a virtual assistant and not a replacement for a certified doctor. For serious medical concerns, please consult with a healthcare professional.`;
};

export default function useDrAtlas(language: string = 'en') {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [showEmergency, setShowEmergency] = useState(false);

  useEffect(() => {
    initializeConversation();
  }, []);

  const initializeConversation = async () => {
    const sessionId = getSessionId();

    const { data, error } = await supabase
      .from('conversations')
      .select('id')
      .eq('session_id', sessionId)
      .maybeSingle();

    if (data) {
      setConversationId(data.id);
      await loadMessages(data.id);
    } else if (!error) {
      const { data: newConv, error: createError } = await supabase
        .from('conversations')
        .insert({
          session_id: sessionId,
          user_id: null,
        })
        .select('id')
        .single();

      if (newConv && !createError) {
        setConversationId(newConv.id);
        await sendWelcomeMessage(newConv.id);
      }
    }
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const sendWelcomeMessage = async (convId: string) => {
    const welcomeMessage: Message = {
      id: crypto.randomUUID(),
      role: 'doctor',
      content: language === 'te'
        ? `నమస్కారం! నేను డాక్టర్ సాయికృష్ణ, మీ స్నేహపూర్వక వర్చువల్ వైద్య సహాయకుడు. మిమ్మల్ని కలవడం చాలా సంతోషంగా ఉంది!

నేను మీకు ఈ విషయాలలో సహాయం చేయడానికి ఇక్కడ ఉన్నాను:
• వైద్య ప్రశ్నలు మరియు ఆరోగ్య సమస్యలు
• లక్షణాలను అర్థం చేసుకోవడం
• ప్రథమ చికిత్స మార్గదర్శకత్వం
• సాధారణ ఆరోగ్య సలహా
• లేదా కేవలం స్నేహపూర్వక సంభాషణ!

ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?`
        : `Hello! I'm Dr. Saikrishna, your friendly virtual medical assistant. It's great to meet you!

I'm here to help you with:
• Medical questions and health concerns
• Understanding symptoms
• First-aid guidance
• General health advice
• Or just having a friendly conversation!

How can I assist you today?`,
      created_at: new Date().toISOString(),
    };

    setMessages([welcomeMessage]);

    await supabase.from('messages').insert({
      conversation_id: convId,
      role: 'doctor',
      content: welcomeMessage.content,
    });
  };

  const sendMessage = async (content: string) => {
    if (!content.trim() || !conversationId) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: content.trim(),
      created_at: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setLoading(true);

    await supabase.from('messages').insert({
      conversation_id: conversationId,
      role: 'user',
      content: userMessage.content,
    });

    if (detectEmergency(content)) {
      setShowEmergency(true);
    }

    setTimeout(async () => {
      const doctorResponse = await generateDoctorResponse(content, messages, language);

      const doctorMessage: Message = {
        id: crypto.randomUUID(),
        role: 'doctor',
        content: doctorResponse,
        created_at: new Date().toISOString(),
      };

      setMessages(prev => [...prev, doctorMessage]);
      setLoading(false);

      await supabase.from('messages').insert({
        conversation_id: conversationId,
        role: 'doctor',
        content: doctorMessage.content,
      });

      await supabase
        .from('conversations')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', conversationId);
    }, 1500);
  };

  const dismissEmergency = () => {
    setShowEmergency(false);
  };

  const resetConversation = async () => {
    if (!conversationId) return;

    await supabase
      .from('messages')
      .delete()
      .eq('conversation_id', conversationId);

    setMessages([]);
    setShowEmergency(false);
  };

  return {
    messages,
    loading,
    sendMessage,
    showEmergency,
    dismissEmergency,
    resetConversation,
  };
}
