export interface Message {
  id: string;
  role: 'user' | 'doctor';
  content: string;
  created_at: string;
}

export interface Conversation {
  id: string;
  session_id: string;
  created_at: string;
  updated_at: string;
}

export interface SymptomAssessment {
  mainConcern: string;
  duration?: string;
  severity?: string;
  additionalSymptoms: string[];
}
