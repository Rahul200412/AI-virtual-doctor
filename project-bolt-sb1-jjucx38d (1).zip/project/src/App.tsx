import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Mic, MicOff, Keyboard, X, RotateCcw, StopCircle, MessageSquare, Minimize2, Maximize2 } from 'lucide-react';
import AnimatedDoctor from './components/AnimatedDoctor';
import ChatMessage from './components/ChatMessage';
import QuickActionButtons from './components/QuickActionButtons';
import MedicalDisclaimer from './components/MedicalDisclaimer';
import EmergencyBanner from './components/EmergencyBanner';
import LanguageSelector from './components/LanguageSelector';
import useDrAtlas from './hooks/useDrAtlas';
import { useLanguage } from './contexts/LanguageContext';

function App() {
  const { language, t } = useLanguage();
  const [inputValue, setInputValue] = useState('');
  const [doctorSpeaking, setDoctorSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showTextInput, setShowTextInput] = useState(false);
  const [chatOpen, setChatOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const { messages, loading, sendMessage, showEmergency, dismissEmergency, resetConversation } = useDrAtlas(language);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);


  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && lastMessage.role === 'doctor') {
      speakMessage(lastMessage.content);
    }
  }, [messages, language]);

  useEffect(() => {
    if (loading) {
      setDoctorSpeaking(true);
    }
  }, [loading]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = language === 'te' ? 'te-IN' : 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        console.log('Voice input received:', transcript);
        sendMessage(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        console.log('Speech recognition ended');
        setIsListening(false);
      };
    }

    return () => {
      if (synthRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, [sendMessage, language]);

  const speakMessage = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);

      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        console.log('Available voices:', voices.map(v => `${v.name} (${v.lang})`));

        let preferredVoice;
        if (language === 'te') {
          preferredVoice = voices.find(voice =>
            voice.lang.includes('te-IN') ||
            voice.lang.includes('te') ||
            voice.name.toLowerCase().includes('telugu')
          );

          if (!preferredVoice) {
            preferredVoice = voices.find(voice =>
              voice.lang.includes('hi-IN') ||
              voice.lang.includes('hi') ||
              voice.name.toLowerCase().includes('hindi')
            );
          }

          if (!preferredVoice) {
            preferredVoice = voices.find(voice =>
              voice.lang.includes('en-IN')
            );
          }

          if (!preferredVoice && voices.length > 0) {
            preferredVoice = voices[0];
          }

          utterance.lang = 'te-IN';
          console.log('Selected voice for Telugu:', preferredVoice ? `${preferredVoice.name} (${preferredVoice.lang})` : 'None');
        } else {
          preferredVoice = voices.find(voice =>
            (voice.name.includes('Male') || voice.name.includes('David') || voice.name.includes('Daniel')) &&
            voice.lang.includes('en')
          ) || voices.find(voice => voice.lang.includes('en-US'));

          utterance.lang = 'en-US';
        }

        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }

        utterance.rate = 0.9;
        utterance.pitch = 0.9;
        utterance.volume = 1;

        utterance.onstart = () => {
          setDoctorSpeaking(true);
        };

        utterance.onend = () => {
          setDoctorSpeaking(false);
          synthRef.current = null;
        };

        utterance.onerror = (event) => {
          console.error('Speech synthesis error:', event);
          setDoctorSpeaking(false);
          synthRef.current = null;
        };

        synthRef.current = utterance;
        window.speechSynthesis.speak(utterance);
      };

      if (window.speechSynthesis.getVoices().length > 0) {
        loadVoices();
      } else {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    } else {
      setDoctorSpeaking(true);
      const duration = Math.max(3000, text.length * 50);
      setTimeout(() => setDoctorSpeaking(false), duration);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (inputValue.trim() && !loading) {
      sendMessage(inputValue);
      setInputValue('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickAction = (message: string) => {
    if (!loading) {
      sendMessage(message);
    }
  };

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      console.log('Stopping voice recognition...');
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        if (doctorSpeaking) {
          window.speechSynthesis.cancel();
          setDoctorSpeaking(false);
        }
        console.log('Starting voice recognition...');
        recognitionRef.current.start();
        setIsListening(true);
      } catch (error) {
        console.error('Error starting voice recognition:', error);
        alert('Failed to start voice recognition. Please try again.');
        setIsListening(false);
      }
    }
  };

  const stopSpeaking = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setDoctorSpeaking(false);
    synthRef.current = null;
  };

  const handleStopAndReset = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setDoctorSpeaking(false);
    synthRef.current = null;

    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.log('Recognition already stopped');
      }
      setIsListening(false);
    }
  };

  const handleNewConversation = async () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setDoctorSpeaking(false);
    }
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
    setInputValue('');
    setShowTextInput(false);
    await resetConversation();
  };

  const handleInitialInput = () => {
    setIsListening(true);
    if (recognitionRef.current) {
      recognitionRef.current.start();
    }
  };

  const getStatusText = () => {
    if (loading) return t('thinking');
    if (doctorSpeaking) return language === 'te' ? 'మాట్లాడుతున్నారు' : 'Speaking';
    if (isListening) return language === 'te' ? 'వింటున్నారు...' : 'Listening...';
    return language === 'te' ? 'సహాయానికి సిద్ధంగా ఉన్నారు' : 'Ready to Help';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-blue-50 relative overflow-hidden">
      {/* Hospital Pattern Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(90deg, #10b981 0px, #10b981 2px, transparent 2px, transparent 40px),
                           repeating-linear-gradient(0deg, #10b981 0px, #10b981 2px, transparent 2px, transparent 40px)`,
        }}></div>
      </div>

      {/* Hospital Header */}
      <header className="relative bg-gradient-to-r from-teal-600 to-teal-700 text-white shadow-xl">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">
                  {language === 'te' ? 'సాయికృష్ణ వర్చువల్ హాస్పిటల్' : 'Saikrishna Virtual Hospital'}
                </h1>
                <p className="text-teal-100 text-sm">
                  {language === 'te' ? '24/7 ఆన్‌లైన్ వైద్య సలహా' : '24/7 Online Medical Consultation'}
                </p>
              </div>
            </div>
            <LanguageSelector />
          </div>
        </div>
      </header>

      {showEmergency && <EmergencyBanner onDismiss={dismissEmergency} />}

      <div className="relative mx-auto p-6 min-h-[calc(100vh-120px)]">
        {false ? (
          <div className="flex items-center justify-center min-h-screen">
            <div className="bg-gradient-to-b from-white to-blue-50 rounded-2xl shadow-2xl p-12 border-2 border-blue-200 max-w-lg">
              <AnimatedDoctor isSpeaking={doctorSpeaking || loading} />
              <div className="mt-8 text-center">
                <h1 className="text-4xl font-bold text-gray-800 mb-3">
                  {language === 'te' ? 'డాక్టర్ సాయికృష్ణ' : 'Dr. Saikrishna'}
                </h1>
                <p className="text-lg text-gray-600 mb-6">
                  {language === 'te' ? 'మీ వర్చువల్ వైద్య సహాయకుడు' : 'Your Virtual Medical Assistant'}
                </p>
                <div className="mb-6">
                  <LanguageSelector />
                </div>
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 ${doctorSpeaking || loading ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                  <div className={`w-2 h-2 rounded-full ${doctorSpeaking || loading ? 'bg-green-500 animate-pulse' : 'bg-blue-500'}`}></div>
                  <span className="text-xs font-semibold">{getStatusText()}</span>
                </div>

                <button
                  onClick={toggleVoiceInput}
                  disabled={loading || doctorSpeaking}
                  className={`w-full px-8 py-5 rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-3 ${
                    isListening
                      ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                      : 'bg-blue-500 hover:bg-blue-600 text-white disabled:bg-gray-300'
                  } disabled:cursor-not-allowed shadow-lg`}
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-7 h-7" />
                      <span>{language === 'te' ? 'వినడం ఆపండి' : 'Stop Listening'}</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-7 h-7" />
                      <span>{language === 'te' ? 'అడగడానికి నొక్కండి' : 'Tap to Ask'}</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => setShowTextInput(!showTextInput)}
                  className="mt-4 text-sm text-blue-600 hover:text-blue-700 underline"
                >
                  {showTextInput
                    ? (language === 'te' ? 'కీబోర్డ్ దాచండి' : 'Hide keyboard')
                    : (language === 'te' ? 'లేదా మీ ప్రశ్న టైప్ చేయండి' : 'Or type your question')
                  }
                </button>

                {showTextInput && (
                  <div className="mt-4 animate-in slide-in-from-bottom-4 duration-300">
                    {language === 'te' && (
                      <p className="text-xs text-gray-600 mb-2 text-center">
                        మీరు తెలుగు కీబోర్డ్ లేదా Google Input Tools ఉపయోగించి టైప్ చేయవచ్చు
                      </p>
                    )}
                    <div className="flex gap-3">
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder={t('typeMessage')}
                        disabled={loading}
                        lang={language === 'te' ? 'te' : 'en'}
                        dir={language === 'te' ? 'ltr' : 'ltr'}
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                        autoFocus
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={loading || !inputValue.trim()}
                        className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <MedicalDisclaimer />
            </div>
          </div>
        ) : (
          <div className={`max-w-7xl mx-auto transition-all duration-700 ease-in-out ${chatOpen ? 'grid lg:grid-cols-[1fr,400px] gap-6' : 'grid md:grid-cols-2 gap-6 items-start'}`}>
            {/* Main Consultation Room - Chat Box */}
            <main className={`space-y-4 transition-all duration-700 ${chatOpen ? 'order-2 lg:order-1' : 'hidden'}`}>
              {showEmergency && (
                <div>
                  <EmergencyBanner
                    show={showEmergency}
                    message={language === 'te'
                      ? 'మీ లక్షణాల ఆధారంగా, మీకు తక్షణ వైద్య సంరక్షణ అవసరం కావచ్చు. దయచేసి ఇప్పుడే అత్యవసర సేవలకు కాల్ చేయండి.'
                      : 'Based on your symptoms, you may need immediate medical attention. Please call emergency services now.'}
                  />
                  <button
                    onClick={dismissEmergency}
                    className="mt-2 text-sm text-gray-600 hover:text-gray-800 underline"
                  >
                    {language === 'te' ? 'ఈ హెచ్చరికను తీసివేయండి' : 'Dismiss this alert'}
                  </button>
                </div>
              )}


              {/* Chat Box (when open) */}
              {chatOpen && (
              <div className="bg-white rounded-xl shadow-2xl border-2 border-teal-200 h-[calc(100vh-180px)] flex flex-col animate-in slide-in-from-right fade-in zoom-in duration-700 ease-out">
                <div className="flex items-center justify-between p-4 border-b-2 border-teal-100 bg-gradient-to-r from-teal-50 to-cyan-50 transition-all duration-300">
                  <div className="flex items-center gap-3 animate-in slide-in-from-left duration-500">
                    <div className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center shadow-lg transition-transform duration-300 hover:scale-110">
                      <MessageSquare className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="font-bold text-gray-800 text-lg transition-all duration-300">
                        {language === 'te' ? 'వైద్య సంప్రదింపులు' : 'Medical Consultation'}
                      </h2>
                      <p className="text-xs text-gray-600">
                        {language === 'te' ? 'డాక్టర్ సాయికృష్ణ' : 'Dr. Saikrishna'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setChatOpen(false)}
                    className="p-2 hover:bg-red-100 rounded-lg transition-all duration-300 group hover:scale-110 active:scale-95"
                    aria-label="Hide chat"
                  >
                    <Minimize2 className="w-5 h-5 text-teal-700 group-hover:text-red-600 transition-colors duration-300" />
                  </button>
                </div>
                <>
              <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-gradient-to-b from-white to-gray-50">
                {messages.map((message) => (
                  <ChatMessage key={message.id} message={message} />
                ))}
                {loading && (
                  <div className="flex gap-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <Loader2 className="w-5 h-5 text-white animate-spin" />
                    </div>
                    <div className="bg-gray-100 rounded-2xl px-4 py-3">
                      <p className="text-sm text-gray-600">{t('thinking')}</p>
                    </div>
                  </div>
                )}
                {isListening && (
                  <div className="flex gap-3 justify-end">
                    <div className="bg-blue-500 text-white rounded-2xl px-4 py-3 flex items-center gap-2">
                      <Mic className="w-5 h-5 animate-pulse" />
                      <p className="text-sm">{language === 'te' ? 'వింటున్నారు...' : 'Listening...'}</p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="border-t border-gray-200 p-4 bg-gradient-to-b from-gray-50 to-white">
                {messages.length <= 1 && !showTextInput && (
                  <div className="mb-4 animate-in slide-in-from-bottom duration-500">
                    <p className="text-sm text-gray-600 mb-3 font-medium">
                      {language === 'te' ? 'త్వరిత చర్యలు:' : 'Quick Actions:'}
                    </p>
                    <QuickActionButtons onActionClick={handleQuickAction} disabled={loading} />
                  </div>
                )}

                <div className="flex flex-col gap-3">
                  <div className="flex gap-3 items-center">
                    <button
                      onClick={toggleVoiceInput}
                      disabled={loading || doctorSpeaking}
                      className={`flex-1 px-6 py-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-3 transform hover:scale-105 active:scale-95 ${
                        isListening
                          ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse shadow-xl shadow-red-500/50'
                          : 'bg-blue-500 hover:bg-blue-600 text-white disabled:bg-gray-300 shadow-lg hover:shadow-xl'
                      } disabled:cursor-not-allowed`}
                    >
                      {isListening ? (
                        <>
                          <MicOff className="w-6 h-6" />
                          <span>{language === 'te' ? 'వినడం ఆపండి' : 'Stop Listening'}</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-6 h-6" />
                          <span>{language === 'te' ? 'మాట్లాడటానికి నొక్కండి' : 'Tap to Speak'}</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => setShowTextInput(!showTextInput)}
                      className="p-4 rounded-lg border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 transform hover:scale-110 active:scale-95 hover:shadow-lg"
                      title={showTextInput
                        ? (language === 'te' ? 'కీబోర్డ్ దాచండి' : 'Hide keyboard')
                        : (language === 'te' ? 'కీబోర్డ్ చూపించు' : 'Show keyboard')
                      }
                    >
                      {showTextInput ? <X className="w-6 h-6 transition-transform duration-300" /> : <Keyboard className="w-6 h-6 transition-transform duration-300" />}
                    </button>
                  </div>

                  {showTextInput && (
                    <div className="animate-in slide-in-from-bottom fade-in zoom-in duration-500">
                      {language === 'te' && (
                        <p className="text-xs text-gray-600 mb-2 animate-in fade-in duration-700">
                          మీరు తెలుగు కీబోర్డ్ లేదా Google Input Tools ఉపయోగించి టైప్ చేయవచ్చు
                        </p>
                      )}
                      <div className="flex gap-3">
                        <input
                          type="text"
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          onKeyDown={handleKeyPress}
                          placeholder={t('typeMessage')}
                          disabled={loading}
                          lang={language === 'te' ? 'te' : 'en'}
                          dir={language === 'te' ? 'ltr' : 'ltr'}
                          className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed transition-all duration-300 focus:shadow-lg"
                          autoFocus
                        />
                        <button
                          onClick={handleSendMessage}
                          disabled={loading || !inputValue.trim()}
                          className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-all duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2 font-medium transform hover:scale-105 active:scale-95 hover:shadow-xl shadow-lg"
                        >
                          {loading ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : (
                            <>
                              <Send className="w-5 h-5" />
                              {t('send')}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              </>
              </div>
              )}
            </main>

            {/* Doctor Panel - Hospital Style */}
            <aside className={`space-y-4 transition-all duration-700 ease-in-out transform ${
              chatOpen
                ? 'order-1 lg:order-2'
                : 'order-1'
            } animate-in fade-in slide-in-from-left duration-700`}>
              <div className={`bg-white rounded-xl shadow-2xl border-2 border-teal-200 transition-all duration-700 ${
                !chatOpen ? 'p-6 shadow-[0_20px_60px_rgba(20,184,166,0.3)]' : 'p-8'
              }`}>
                <div className={`bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl shadow-xl transition-all duration-700 ${
                  !chatOpen ? 'p-4 mb-4 shadow-[0_15px_40px_rgba(20,184,166,0.4)]' : 'p-8 mb-6'
                }`}>
                  <AnimatedDoctor isSpeaking={doctorSpeaking || loading} />
                </div>

                <div className="text-center space-y-4">
                  <div className="transition-all duration-500">
                    <h3 className={`font-bold text-gray-800 mb-1 transition-all duration-500 ${
                      !chatOpen ? 'text-2xl' : 'text-2xl'
                    }`}>
                      {language === 'te' ? 'డాక్టర్ సాయికృష్ణ' : 'Dr. Saikrishna'}
                    </h3>
                    <p className={`text-gray-600 transition-all duration-500 ${
                      !chatOpen ? 'text-sm' : 'text-sm'
                    }`}>
                      {language === 'te' ? 'వర్చువల్ వైద్య సలహాదారు' : 'Virtual Medical Consultant'}
                    </p>
                  </div>

                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-500 ${
                    doctorSpeaking || loading ? 'bg-green-100 text-green-700' : 'bg-teal-100 text-teal-700'
                  }`}>
                    <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      doctorSpeaking || loading ? 'bg-green-500 animate-pulse' : 'bg-teal-500'
                    }`}></div>
                    <span className="text-xs font-semibold">{getStatusText()}</span>
                  </div>

                  <div className="flex gap-2 justify-center flex-wrap pt-4">
                    {doctorSpeaking && (
                      <button
                        onClick={stopSpeaking}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-medium transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 transform"
                      >
                        <StopCircle className="w-4 h-4" />
                        {language === 'te' ? 'ఆపండి' : 'Stop'}
                      </button>
                    )}

                    <button
                      onClick={handleNewConversation}
                      className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm font-medium transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 transform"
                    >
                      <RotateCcw className="w-4 h-4" />
                      {language === 'te' ? 'కొత్త సంప్రదింపు' : 'New Consultation'}
                    </button>
                  </div>
                </div>
              </div>

              <div className={`bg-gradient-to-br from-teal-50 to-cyan-50 rounded-xl shadow-lg border border-teal-200 transition-all duration-700 ${
                !chatOpen ? 'p-4 shadow-xl' : 'p-6'
              }`}>
                <h4 className="font-bold text-teal-800 mb-3 text-sm uppercase tracking-wide">
                  {language === 'te' ? 'హాస్పిటల్ సమాచారం' : 'Hospital Info'}
                </h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-teal-500 rounded-full"></span>
                    {language === 'te' ? '24/7 అందుబాటు' : '24/7 Available'}
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-teal-500 rounded-full"></span>
                    {language === 'te' ? 'ఉచిత సంప్రదింపు' : 'Free Consultation'}
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-teal-500 rounded-full"></span>
                    {language === 'te' ? 'గోప్యత హామీ' : 'Privacy Guaranteed'}
                  </li>
                </ul>
              </div>

              <MedicalDisclaimer />
            </aside>

            {/* Input Controls Panel - Show when chat is hidden */}
            {!chatOpen && (
              <div className="space-y-4 order-2 animate-in fade-in slide-in-from-right duration-700">
                <div className="bg-white rounded-xl shadow-xl border-2 border-teal-200 p-6 space-y-4">
                  {/* Quick Actions */}
                  {messages.length <= 1 && !showTextInput && (
                    <div className="animate-in slide-in-from-bottom duration-500">
                      <p className="text-sm text-gray-600 mb-3 font-medium">
                        {language === 'te' ? 'త్వరిత చర్యలు:' : 'Quick Actions:'}
                      </p>
                      <QuickActionButtons onActionClick={handleQuickAction} disabled={loading} />
                    </div>
                  )}

                  {/* Voice Input Button */}
                  <button
                    onClick={toggleVoiceInput}
                    disabled={loading || doctorSpeaking}
                    className={`w-full px-6 py-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-3 transform hover:scale-105 active:scale-95 ${
                      isListening
                        ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse shadow-xl shadow-red-500/50'
                        : 'bg-blue-500 hover:bg-blue-600 text-white disabled:bg-gray-300 shadow-lg hover:shadow-xl'
                    } disabled:cursor-not-allowed`}
                  >
                    {isListening ? (
                      <>
                        <MicOff className="w-6 h-6" />
                        <span>{language === 'te' ? 'వినడం ఆపండి' : 'Stop Listening'}</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-6 h-6" />
                        <span>{language === 'te' ? 'మాట్లాడటానికి నొక్కండి' : 'Tap to Speak'}</span>
                      </>
                    )}
                  </button>

                  {/* Keyboard Toggle Button */}
                  <button
                    onClick={() => setShowTextInput(!showTextInput)}
                    className="w-full p-4 rounded-lg border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 active:scale-95 hover:shadow-lg flex items-center justify-center gap-2"
                    title={showTextInput
                      ? (language === 'te' ? 'కీబోర్డ్ దాచండి' : 'Hide keyboard')
                      : (language === 'te' ? 'కీబోర్డ్ చూపించు' : 'Show keyboard')
                    }
                  >
                    {showTextInput ? (
                      <>
                        <X className="w-6 h-6 transition-transform duration-300" />
                        <span className="font-medium">{language === 'te' ? 'కీబోర్డ్ దాచండి' : 'Hide Keyboard'}</span>
                      </>
                    ) : (
                      <>
                        <Keyboard className="w-6 h-6 transition-transform duration-300" />
                        <span className="font-medium">{language === 'te' ? 'కీబోర్డ్ చూపించు' : 'Show Keyboard'}</span>
                      </>
                    )}
                  </button>

                  {/* Text Input */}
                  {showTextInput && (
                    <div className="animate-in slide-in-from-bottom fade-in zoom-in duration-500">
                      {language === 'te' && (
                        <p className="text-xs text-gray-600 mb-2 animate-in fade-in duration-700">
                          మీరు తెలుగు కీబోర్డ్ లేదా Google Input Tools ఉపయోగించి టైప్ చేయవచ్చు
                        </p>
                      )}
                      <div className="flex flex-col gap-3">
                        <input
                          type="text"
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          onKeyDown={handleKeyPress}
                          placeholder={t('typeMessage')}
                          disabled={loading}
                          lang={language === 'te' ? 'te' : 'en'}
                          dir={language === 'te' ? 'ltr' : 'ltr'}
                          className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed transition-all duration-300 focus:shadow-lg"
                          autoFocus
                        />
                        <button
                          onClick={handleSendMessage}
                          disabled={loading || !inputValue.trim()}
                          className="w-full bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-all duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-medium transform hover:scale-105 active:scale-95 hover:shadow-xl shadow-lg"
                        >
                          {loading ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : (
                            <>
                              <Send className="w-5 h-5" />
                              {t('send')}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Floating Chat Button (when hidden) */}
      {!chatOpen && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in zoom-in duration-500">
          {/* Ripple effect background */}
          <div className="absolute inset-0 bg-teal-500 rounded-full opacity-20 animate-ping"></div>
          <div className="absolute inset-0 bg-teal-400 rounded-full opacity-30 animate-pulse"></div>

          <button
            onClick={() => setChatOpen(true)}
            className="relative w-16 h-16 bg-gradient-to-br from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-125 hover:rotate-12 active:scale-95 group"
            aria-label="Open chat"
          >
            <MessageSquare className="w-8 h-8 transition-transform duration-300 group-hover:scale-110" />
            {messages.length > 1 && (
              <span className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full text-xs flex items-center justify-center font-bold animate-bounce shadow-lg">
                {messages.length}
              </span>
            )}

            {/* Glow effect on hover */}
            <div className="absolute inset-0 rounded-full bg-white opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
          </button>

          {/* Tooltip */}
          <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none">
            {language === 'te' ? 'చాట్ చరిత్రను చూడండి' : 'View Chat History'}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="text-center py-6 relative bg-gradient-to-r from-teal-600 to-teal-700 text-white">
        <p className="text-sm">
          {language === 'te'
            ? 'అత్యవసర పరిస్థితుల కోసం, 108కు కాల్ చేయండి'
            : 'For emergencies, dial 911 (US) or 108 (India)'}
        </p>
      </footer>
    </div>
  );
}

export default App;
