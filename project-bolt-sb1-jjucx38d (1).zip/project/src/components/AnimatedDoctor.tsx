import { useEffect, useState } from 'react';

interface AnimatedDoctorProps {
  isSpeaking: boolean;
}

export default function AnimatedDoctor({ isSpeaking }: AnimatedDoctorProps) {
  const [mouthOpen, setMouthOpen] = useState(false);
  const [mouthWidth, setMouthWidth] = useState(0);
  const [blink, setBlink] = useState(false);
  const [headBob, setHeadBob] = useState(0);

  useEffect(() => {
    let mouthInterval: NodeJS.Timeout;
    let bobInterval: NodeJS.Timeout;

    if (isSpeaking) {
      let cycle = 0;
      mouthInterval = setInterval(() => {
        const variations = [
          { open: true, width: 0.9 },
          { open: false, width: 0.3 },
          { open: true, width: 1 },
          { open: false, width: 0.5 },
          { open: true, width: 0.7 },
          { open: false, width: 0.2 }
        ];

        const current = variations[cycle % variations.length];
        setMouthOpen(current.open);
        setMouthWidth(current.width);
        cycle++;
      }, 180);

      let bobCycle = 0;
      bobInterval = setInterval(() => {
        setHeadBob(Math.sin(bobCycle) * 2);
        bobCycle += 0.3;
      }, 50);
    } else {
      setMouthOpen(false);
      setMouthWidth(0);
      setHeadBob(0);
    }

    return () => {
      if (mouthInterval) clearInterval(mouthInterval);
      if (bobInterval) clearInterval(bobInterval);
    };
  }, [isSpeaking]);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => {
        setBlink(false);
      }, 150);
    }, 4000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  return (
    <div className="relative flex items-center justify-center py-8">
      <div className={`transition-all duration-300 ${isSpeaking ? 'scale-[1.02]' : 'scale-100'}`}>
        <svg width="380" height="460" viewBox="0 0 380 460" className="mx-auto drop-shadow-2xl">
          <defs>
            <linearGradient id="skinGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFE8DC" />
              <stop offset="100%" stopColor="#FFDCCF" />
            </linearGradient>
            <linearGradient id="hairGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#C4B5C8" />
              <stop offset="30%" stopColor="#AFA0B8" />
              <stop offset="100%" stopColor="#998AA8" />
            </linearGradient>
            <linearGradient id="hairShine" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#D8CCE0" />
              <stop offset="100%" stopColor="#C4B5C8" />
            </linearGradient>
            <linearGradient id="coatGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#F7F9FC" />
            </linearGradient>
            <linearGradient id="shirtGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#7EC8E3" />
              <stop offset="100%" stopColor="#6AB5D3" />
            </linearGradient>
            <radialGradient id="eyeGradient">
              <stop offset="0%" stopColor="#B8956D" />
              <stop offset="100%" stopColor="#8B6F4A" />
            </radialGradient>
            <filter id="softGlow">
              <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>

          <ellipse cx="190" cy="435" rx="130" ry="22" fill="#00000018" />

          <g className="body">
            <rect x="95" y="220" width="190" height="240" rx="28" fill="url(#coatGradient)" stroke="#DDE5EF" strokeWidth="2" />

            <rect x="135" y="220" width="110" height="240" fill="url(#shirtGradient)" />


            <rect x="135" y="230" width="110" height="14" rx="4" fill="url(#shirtGradient)" />

            <path d="M 135 230 L 128 260 L 135 252 Z" fill="#FFFFFF" stroke="#DDE5EF" strokeWidth="1" />
            <path d="M 245 230 L 252 260 L 245 252 Z" fill="#FFFFFF" stroke="#DDE5EF" strokeWidth="1" />

            <g className="left-arm">
              <rect x="40" y="280" width="55" height="160" rx="28" fill="url(#coatGradient)" stroke="#DDE5EF" strokeWidth="2" />
            </g>

            <g className="right-arm">
              <rect x="285" y="280" width="55" height="160" rx="28" fill="url(#coatGradient)" stroke="#DDE5EF" strokeWidth="2" />
            </g>

            <line x="145" y="245" x2="235" y2="245" stroke="#FFFFFF" strokeWidth="2.5" opacity="0.5" />
          </g>

          <g className="stethoscope">
            <path d="M 230 235 Q 235 255, 240 280" stroke="#3C5060" strokeWidth="3.5" fill="none" strokeLinecap="round" />
            <path d="M 240 280 Q 245 310, 235 340" stroke="#3C5060" strokeWidth="3.5" fill="none" strokeLinecap="round" />
            <path d="M 235 340 Q 225 370, 237 395" stroke="#3C5060" strokeWidth="3.5" fill="none" strokeLinecap="round" />

            <circle cx="237" cy="403" r="15" fill="#3C5060" />
            <circle cx="237" cy="403" r="11" fill="#4A6478" />
            <circle cx="237" cy="403" r="7" fill="#5A7488" />
            <circle cx="239" cy="401" r="3.5" fill="#93AAC0" />

            <path d="M 230 235 Q 240 242, 248 252" stroke="#3C5060" strokeWidth="3.5" fill="none" strokeLinecap="round" />

            <ellipse cx="250" cy="256" rx="11" ry="10" fill="#3C5060" transform="rotate(-30 250 256)" stroke="#4A6478" strokeWidth="1.5" />
            <ellipse cx="258" cy="262" rx="11" ry="10" fill="#3C5060" transform="rotate(-30 258 262)" stroke="#4A6478" strokeWidth="1.5" />
          </g>

          <g className="neck">
            <rect x="165" y="180" width="50" height="45" rx="8" fill="url(#skinGradient)" />
          </g>

          <g className="head" transform={`translate(0, ${headBob})`}>
            <ellipse cx="190" cy="120" rx="85" ry="95" fill="url(#skinGradient)" stroke="#FFDCCF" strokeWidth="1.5" />

            <ellipse cx="190" cy="45" rx="95" ry="62" fill="url(#hairGradient)" />

            <path d="M 100 85 Q 100 50, 130 32 Q 160 20, 190 18 Q 220 20, 250 32 Q 280 50, 280 85 Z" fill="url(#hairGradient)" />

            <ellipse cx="150" cy="55" rx="25" ry="15" fill="url(#hairShine)" opacity="0.4" />

            <path d="M 108 82 Q 115 72, 125 70 Q 135 68, 145 72 L 148 88 Z" fill="url(#hairGradient)" />
            <path d="M 272 82 Q 265 72, 255 70 Q 245 68, 235 72 L 232 88 Z" fill="url(#hairGradient)" />

            <path d="M 115 95 Q 120 88, 130 90" fill="url(#hairGradient)" />
            <path d="M 265 95 Q 260 88, 250 90" fill="url(#hairGradient)" />

            <path d="M 135 105 Q 137 100, 145 102" stroke="#998AA8" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 245 105 Q 243 100, 235 102" stroke="#998AA8" strokeWidth="5" fill="none" strokeLinecap="round" />

            <ellipse cx="120" cy="135" rx="16" ry="18" fill="#FFBFA8" opacity="0.5" />
            <ellipse cx="260" cy="135" rx="16" ry="18" fill="#FFBFA8" opacity="0.5" />

            <g className="left-eye">
              <ellipse cx="155" cy="120" rx="22" ry="26" fill="#FFFFFF" />
              <ellipse cx="155" cy="120" rx="18" ry={blink ? "2" : "22"} fill="url(#eyeGradient)" className="transition-all duration-150" />
              {!blink && (
                <>
                  <circle cx="158" cy="117" r="9" fill="#4A3A2A" />
                  <circle cx="161" cy="113" r="5.5" fill="#FFFFFF" opacity="0.95" />
                  <circle cx="156" cy="119" r="3" fill="#FFFFFF" opacity="0.75" />
                  <ellipse cx="164" cy="124" rx="4" ry="2.5" fill="#FFFFFF" opacity="0.5" />
                </>
              )}
              {!blink && (
                <path d="M 135 106 Q 145 104, 155 105" stroke="#998AA8" strokeWidth="1" fill="none" opacity="0.3" />
              )}
            </g>

            <g className="right-eye">
              <ellipse cx="225" cy="120" rx="22" ry="26" fill="#FFFFFF" />
              <ellipse cx="225" cy="120" rx="18" ry={blink ? "2" : "22"} fill="url(#eyeGradient)" className="transition-all duration-150" />
              {!blink && (
                <>
                  <circle cx="228" cy="117" r="9" fill="#4A3A2A" />
                  <circle cx="231" cy="113" r="5.5" fill="#FFFFFF" opacity="0.95" />
                  <circle cx="226" cy="119" r="3" fill="#FFFFFF" opacity="0.75" />
                  <ellipse cx="234" cy="124" rx="4" ry="2.5" fill="#FFFFFF" opacity="0.5" />
                </>
              )}
              {!blink && (
                <path d="M 245 106 Q 235 104, 225 105" stroke="#998AA8" strokeWidth="1" fill="none" opacity="0.3" />
              )}
            </g>

            <path d="M 185 148 L 195 148" stroke="#FFDCCF" strokeWidth="2" strokeLinecap="round" />
            <path d="M 183 152 Q 190 156, 197 152" stroke="#FFDCCF" strokeWidth="1.5" fill="none" strokeLinecap="round" />

            <path d="M 186 154 Q 190 155, 194 154" stroke="#FFD0C0" strokeWidth="1" fill="none" opacity="0.5" />

            <g className="mouth">
              {isSpeaking ? (
                <>
                  <path
                    d={mouthOpen
                      ? `M ${162 + (1 - mouthWidth) * 5} 172 Q ${165 + (1 - mouthWidth) * 3} ${185 - mouthWidth * 3}, 190 ${187 - mouthWidth * 2} Q ${215 - (1 - mouthWidth) * 3} ${185 - mouthWidth * 3}, ${218 - (1 - mouthWidth) * 5} 172 Q ${215 - (1 - mouthWidth) * 3} ${182 - mouthWidth * 2}, 190 ${184 - mouthWidth * 2} Q ${165 + (1 - mouthWidth) * 3} ${182 - mouthWidth * 2}, ${162 + (1 - mouthWidth) * 5} 172 Z`
                      : `M ${162 + (1 - mouthWidth) * 8} 172 Q ${170 + (1 - mouthWidth) * 5} ${180 - mouthWidth * 5}, 190 ${181 - mouthWidth * 5} Q ${210 - (1 - mouthWidth) * 5} ${180 - mouthWidth * 5}, ${218 - (1 - mouthWidth) * 8} 172`}
                    fill={mouthOpen ? "#FF8BA5" : "#FFA8B8"}
                    stroke="#FF7095"
                    strokeWidth="2"
                    className="transition-all duration-150 ease-out"
                  />
                  {mouthOpen && (
                    <>
                      <ellipse cx="190" cy={180 - mouthWidth * 2} rx={14 * mouthWidth} ry={8 * mouthWidth} fill="#EE6A8A" className="transition-all duration-150" />
                      <rect x={176 + (1 - mouthWidth) * 10} y={175 - mouthWidth * 2} width={28 * mouthWidth} height="4" rx="2" fill="#FFFFFF" opacity="0.95" className="transition-all duration-150" />
                    </>
                  )}
                </>
              ) : (
                <path d="M 168 172 Q 190 178, 212 172" stroke="#FFA8B8" strokeWidth="3" fill="none" strokeLinecap="round" />
              )}
            </g>

            <path d="M 147 130 Q 149 133, 152 131" stroke="#FFD0C0" strokeWidth="0.8" fill="none" opacity="0.4" />
            <path d="M 233 130 Q 231 133, 228 131" stroke="#FFD0C0" strokeWidth="0.8" fill="none" opacity="0.4" />
          </g>

          {isSpeaking && (
            <g className="speech-lines" opacity="0.8">
              <g className="animate-pulse" style={{ animationDuration: '1.5s' }}>
                <path d="M 75 100 Q 60 95, 45 100" stroke="#6AB5D3" strokeWidth="3" fill="none" strokeLinecap="round" />
                <circle cx="45" cy="100" r="2.5" fill="#6AB5D3" />
                <circle cx="35" cy="105" r="2" fill="#6AB5D3" opacity="0.7" />
                <circle cx="28" cy="112" r="1.5" fill="#6AB5D3" opacity="0.5" />
              </g>
              <g className="animate-pulse" style={{ animationDuration: '1.5s', animationDelay: '0.3s' }}>
                <path d="M 70 125 Q 55 120, 40 125" stroke="#7EC8E3" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                <circle cx="40" cy="125" r="2" fill="#7EC8E3" />
                <circle cx="32" cy="130" r="1.5" fill="#7EC8E3" opacity="0.7" />
              </g>
              <g className="animate-pulse" style={{ animationDuration: '1.5s', animationDelay: '0.6s' }}>
                <path d="M 65 145 Q 50 140, 35 145" stroke="#5AB0CC" strokeWidth="2" fill="none" strokeLinecap="round" />
                <circle cx="35" cy="145" r="1.5" fill="#5AB0CC" />
              </g>

              <g className="animate-pulse" style={{ animationDuration: '1.5s', animationDelay: '0.2s' }}>
                <path d="M 305 100 Q 320 95, 335 100" stroke="#6AB5D3" strokeWidth="3" fill="none" strokeLinecap="round" />
                <circle cx="335" cy="100" r="2.5" fill="#6AB5D3" />
                <circle cx="345" cy="105" r="2" fill="#6AB5D3" opacity="0.7" />
                <circle cx="352" cy="112" r="1.5" fill="#6AB5D3" opacity="0.5" />
              </g>
              <g className="animate-pulse" style={{ animationDuration: '1.5s', animationDelay: '0.5s' }}>
                <path d="M 310 125 Q 325 120, 340 125" stroke="#7EC8E3" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                <circle cx="340" cy="125" r="2" fill="#7EC8E3" />
                <circle cx="348" cy="130" r="1.5" fill="#7EC8E3" opacity="0.7" />
              </g>
              <g className="animate-pulse" style={{ animationDuration: '1.5s', animationDelay: '0.8s' }}>
                <path d="M 315 145 Q 330 140, 345 145" stroke="#5AB0CC" strokeWidth="2" fill="none" strokeLinecap="round" />
                <circle cx="345" cy="145" r="1.5" fill="#5AB0CC" />
              </g>
            </g>
          )}
        </svg>

        {isSpeaking && (
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex gap-2.5">
            <div className="w-3 h-3 bg-cyan-500 rounded-full animate-bounce shadow-lg" style={{ animationDelay: '0ms' }}></div>
            <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce shadow-lg" style={{ animationDelay: '150ms' }}></div>
            <div className="w-3 h-3 bg-cyan-500 rounded-full animate-bounce shadow-lg" style={{ animationDelay: '300ms' }}></div>
          </div>
        )}

        {isSpeaking && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[420px] h-[420px] bg-cyan-300 rounded-full opacity-8 animate-ping"></div>
          </div>
        )}
      </div>
    </div>
  );
}
