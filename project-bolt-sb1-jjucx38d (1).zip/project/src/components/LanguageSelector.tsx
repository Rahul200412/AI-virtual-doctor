import { Languages } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function LanguageSelector() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="flex items-center gap-2 bg-white rounded-xl px-4 py-2 shadow-lg border border-gray-200">
      <Languages className="w-5 h-5 text-cyan-600" />
      <span className="text-sm font-medium text-gray-700">{t('selectLanguage')}:</span>
      <div className="flex gap-2">
        <button
          onClick={() => setLanguage('en')}
          className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
            language === 'en'
              ? 'bg-cyan-600 text-white shadow-md'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          English
        </button>
        <button
          onClick={() => setLanguage('te')}
          className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
            language === 'te'
              ? 'bg-cyan-600 text-white shadow-md'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          తెలుగు
        </button>
      </div>
    </div>
  );
}
