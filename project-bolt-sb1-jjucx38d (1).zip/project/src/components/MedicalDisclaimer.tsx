import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function MedicalDisclaimer() {
  const { language } = useLanguage();

  return (
    <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-lg shadow-sm">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-semibold text-amber-900">
            {language === 'te' ? 'వైద్య నిరాకరణ' : 'Medical Disclaimer'}
          </p>
          <p className="text-xs text-amber-800 mt-1">
            {language === 'te'
              ? 'నేను వర్చువల్ అసిస్టెంట్‌ని మరియు ధృవీకరించబడిన వైద్యునికి ప్రత్యామ్నాయం కాను. అత్యవసర పరిస్థితుల కోసం, 108కు కాల్ చేయండి లేదా మీ సమీపంలోని అత్యవసర గదిని వెంటనే సందర్శించండి.'
              : "I'm a virtual assistant and not a replacement for a certified doctor. For emergencies, call 911 or visit your nearest emergency room immediately."}
          </p>
        </div>
      </div>
    </div>
  );
}
