import { Heart, Thermometer, Activity, HelpCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface QuickActionButtonsProps {
  onActionClick: (action: string) => void;
  disabled?: boolean;
}

export default function QuickActionButtons({ onActionClick, disabled }: QuickActionButtonsProps) {
  const { language } = useLanguage();

  const actions = [
    {
      icon: Heart,
      label: language === 'te' ? 'ఛాతీ నొప్పి' : 'Chest Pain',
      message: language === 'te' ? 'నాకు ఛాతీ నొప్పి అనుభవం అవుతోంది' : 'I am experiencing chest pain',
      color: 'bg-red-50 hover:bg-red-100 border-red-200 text-red-700',
    },
    {
      icon: Thermometer,
      label: language === 'te' ? 'జ్వరం' : 'Fever',
      message: language === 'te' ? 'నాకు జ్వరం ఉంది' : 'I have a fever',
      color: 'bg-orange-50 hover:bg-orange-100 border-orange-200 text-orange-700',
    },
    {
      icon: Activity,
      label: language === 'te' ? 'గాయం' : 'Injury',
      message: language === 'te' ? 'నాకు గాయం అయింది' : 'I have an injury',
      color: 'bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700',
    },
    {
      icon: HelpCircle,
      label: language === 'te' ? 'ఇతర' : 'Other',
      message: language === 'te' ? 'నాకు వేరే విషయంలో సహాయం కావాలి' : 'I need help with something else',
      color: 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {actions.map((action) => (
        <button
          key={action.label}
          onClick={() => onActionClick(action.message)}
          disabled={disabled}
          className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${action.color} disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          <action.icon className="w-6 h-6" />
          <span className="text-sm font-medium">{action.label}</span>
        </button>
      ))}
    </div>
  );
}
