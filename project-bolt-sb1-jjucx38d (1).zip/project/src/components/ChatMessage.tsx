import { User, Stethoscope } from 'lucide-react';
import { Message } from '../types';

interface ChatMessageProps {
  message: Message;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const isDoctor = message.role === 'doctor';

  const formatContent = (content: string) => {
    // Replace both \\n (escaped) and \n (literal) with actual newlines
    return content.replace(/\\\\n/g, '\n').replace(/\\n/g, '\n');
  };

  return (
    <div className={`flex gap-3 ${isDoctor ? 'flex-row' : 'flex-row-reverse'}`}>
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden ${
          isDoctor ? 'bg-blue-500 border-2 border-blue-400' : 'bg-gray-500'
        }`}
      >
        {isDoctor ? (
          <img src="/needed doctor.jpg" alt="Dr. Saikrishna" className="w-full h-full object-cover" />
        ) : (
          <User className="w-5 h-5 text-white" />
        )}
      </div>
      <div
        className={`max-w-[70%] rounded-2xl px-4 py-3 shadow-sm ${
          isDoctor
            ? 'bg-white border border-blue-100 text-gray-800'
            : 'bg-blue-500 text-white'
        }`}
      >
        <p className="text-sm whitespace-pre-wrap leading-relaxed">{formatContent(message.content)}</p>
        <span
          className={`text-xs mt-2 block ${
            isDoctor ? 'text-gray-400' : 'text-blue-100'
          }`}
        >
          {new Date(message.created_at).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          })}
        </span>
      </div>
    </div>
  );
}
