import { AlertCircle, Phone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface EmergencyBannerProps {
  show: boolean;
  message: string;
}

export default function EmergencyBanner({ show, message }: EmergencyBannerProps) {
  const { language } = useLanguage();
  if (!show) return null;

  return (
    <div className="bg-red-600 text-white p-4 rounded-lg shadow-lg animate-pulse">
      <div className="flex items-center gap-3">
        <AlertCircle className="w-6 h-6 flex-shrink-0" />
        <div className="flex-1">
          <p className="font-bold text-sm">{language === 'te' ? 'అత్యవసర హెచ్చరిక' : 'EMERGENCY ALERT'}</p>
          <p className="text-sm mt-1">{message}</p>
        </div>
        <a
          href={language === 'te' ? 'tel:108' : 'tel:911'}
          className="flex items-center gap-2 bg-white text-red-600 px-4 py-2 rounded-lg font-bold hover:bg-red-50 transition-colors"
        >
          <Phone className="w-4 h-4" />
          {language === 'te' ? '108 కాల్ చేయండి' : 'Call 911'}
        </a>
      </div>
    </div>
  );
}
