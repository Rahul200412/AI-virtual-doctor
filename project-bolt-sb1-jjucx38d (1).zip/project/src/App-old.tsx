import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Mic, MicOff, Keyboard, X, RotateCcw, StopCircle, MessageSquare, ChevronDown } from 'lucide-react';
import AnimatedDoctor from './components/AnimatedDoctor';
import ChatMessage from './components/ChatMessage';
import QuickActionButtons from './components/QuickActionButtons';
import MedicalDisclaimer from './components/MedicalDisclaimer';
import EmergencyBanner from './components/EmergencyBanner';
import useDrAtlas from './hooks/useDrAtlas';

function App() {
  const [inputValue, setInputValue] = useState('');
  const [doctorSpeaking, setDoctorSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showTextInput, setShowTextInput] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const { messages, loading, sendMessage, showEmergency, dismissEmergency, resetConversation } = useDrAtlas();

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && lastMessage.role === 'doctor') {
      speakMessage(lastMessage.content);
    }
  }, [messages]);

  useEffect(() => {
    if (loading) {
      setDoctorSpeaking(true);
    }
  }, [loading]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        console.log('Voice input received:', transcript);
        sendMessage(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        console.log('Speech recognition ended');
        setIsListening(false);
      };
    }

    return () => {
      if (synthRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, [sendMessage]);

  const speakMessage = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);

      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice =>
        (voice.name.includes('Male') || voice.name.includes('David') || voice.name.includes('Daniel')) &&
        voice.lang.includes('en')
      ) || voices.find(voice => voice.lang.includes('en-US')) || voices[0];

      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.rate = 0.9;
      utterance.pitch = 0.9;
      utterance.volume = 1;

      utterance.onstart = () => {
        setDoctorSpeaking(true);
      };

      utterance.onend = () => {
        setDoctorSpeaking(false);
        synthRef.current = null;
      };

      utterance.onerror = () => {
        setDoctorSpeaking(false);
        synthRef.current = null;
      };

      synthRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    } else {
      setDoctorSpeaking(true);
      const duration = Math.max(3000, text.length * 50);
      setTimeout(() => setDoctorSpeaking(false), duration);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (inputValue.trim() && !loading) {
      sendMessage(inputValue);
      setInputValue('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickAction = (message: string) => {
    if (!loading) {
      sendMessage(message);
    }
  };

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      console.log('Stopping voice recognition...');
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        if (doctorSpeaking) {
          window.speechSynthesis.cancel();
          setDoctorSpeaking(false);
        }
        console.log('Starting voice recognition...');
        recognitionRef.current.start();
        setIsListening(true);
      } catch (error) {
        console.error('Error starting voice recognition:', error);
        alert('Failed to start voice recognition. Please try again.');
        setIsListening(false);
      }
    }
  };

  const stopSpeaking = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setDoctorSpeaking(false);
    synthRef.current = null;
  };

  const handleStopAndReset = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setDoctorSpeaking(false);
    synthRef.current = null;

    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.log('Recognition already stopped');
      }
      setIsListening(false);
    }
  };

  const handleNewConversation = async () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setDoctorSpeaking(false);
    }
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
    setInputValue('');
    setShowTextInput(false);
    await resetConversation();
  };

  const handleInitialInput = () => {
    setIsListening(true);
    if (recognitionRef.current) {
      recognitionRef.current.start();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-cyan-100">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMDAwMDAzIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

      <div className="relative mx-auto p-4 min-h-screen">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center min-h-screen">
            <div className="bg-gradient-to-b from-white to-blue-50 rounded-2xl shadow-2xl p-12 border-2 border-blue-200 max-w-lg">
              <AnimatedDoctor isSpeaking={doctorSpeaking || loading} />
              <div className="mt-8 text-center">
                <h1 className="text-4xl font-bold text-gray-800 mb-3">Dr. Saikrishna</h1>
                <p className="text-lg text-gray-600 mb-6">Your Virtual Medical Assistant</p>
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 ${doctorSpeaking || loading ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                  <div className={`w-2 h-2 rounded-full ${doctorSpeaking || loading ? 'bg-green-500 animate-pulse' : 'bg-blue-500'}`}></div>
                  <span className="text-xs font-semibold">
                    {loading ? 'Thinking...' : doctorSpeaking ? 'Speaking' : isListening ? 'Listening...' : 'Ready to Help'}
                  </span>
                </div>

                <button
                  onClick={toggleVoiceInput}
                  disabled={loading || doctorSpeaking}
                  className={`w-full px-8 py-5 rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-3 ${
                    isListening
                      ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                      : 'bg-blue-500 hover:bg-blue-600 text-white disabled:bg-gray-300'
                  } disabled:cursor-not-allowed shadow-lg`}
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-7 h-7" />
                      <span>Stop Listening</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-7 h-7" />
                      <span>Tap to Ask</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => setShowTextInput(!showTextInput)}
                  className="mt-4 text-sm text-blue-600 hover:text-blue-700 underline"
                >
                  {showTextInput ? 'Hide keyboard' : 'Or type your question'}
                </button>

                {showTextInput && (
                  <div className="flex gap-3 mt-4 animate-in slide-in-from-bottom-4 duration-300">
                    <input
                      type="text"
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyDown={handleKeyPress}
                      placeholder="Type your question..."
                      disabled={loading}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                      autoFocus
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={loading || !inputValue.trim()}
                      className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
              <MedicalDisclaimer />
            </div>
          </div>
        ) : (
          <div className="grid lg:grid-cols-[380px,1fr] gap-6 max-w-7xl mx-auto">
            <aside className="lg:sticky lg:top-4 lg:h-[calc(100vh-2rem)] space-y-4 animate-in slide-in-from-left duration-500">
              <div className="bg-gradient-to-b from-white to-blue-50 rounded-2xl shadow-2xl p-6 border-2 border-blue-200">
                <AnimatedDoctor isSpeaking={doctorSpeaking || loading} />
                <div className="mt-6 text-center">
                  <h1 className="text-2xl font-bold text-gray-800 mb-2">Dr. Saikrishna</h1>
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${doctorSpeaking || loading ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                    <div className={`w-2 h-2 rounded-full ${doctorSpeaking || loading ? 'bg-green-500 animate-pulse' : 'bg-blue-500'}`}></div>
                    <span className="text-xs font-semibold">
                      {loading ? 'Thinking...' : doctorSpeaking ? 'Speaking' : 'Ready to Help'}
                    </span>
                  </div>

                  <div className="flex gap-2 mt-4 justify-center flex-wrap">
                    {doctorSpeaking && (
                      <button
                        onClick={stopSpeaking}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-medium transition-colors shadow-md"
                      >
                        <StopCircle className="w-4 h-4" />
                        Stop Speaking
                      </button>
                    )}

                    <button
                      onClick={handleNewConversation}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors shadow-md"
                    >
                      <RotateCcw className="w-4 h-4" />
                      New Input
                    </button>
                  </div>
                </div>
              </div>
              <MedicalDisclaimer />
            </aside>

            <main className="space-y-4 animate-in slide-in-from-right duration-500">
              {showEmergency && (
                <div>
                  <EmergencyBanner
                    show={showEmergency}
                    message="Based on your symptoms, you may need immediate medical attention. Please call emergency services now."
                  />
                  <button
                    onClick={dismissEmergency}
                    className="mt-2 text-sm text-gray-600 hover:text-gray-800 underline"
                  >
                    Dismiss this alert
                  </button>
                </div>
              )}

              <div className="bg-white rounded-xl shadow-xl border border-gray-200 flex flex-col h-[calc(100vh-2rem)]">
                <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-cyan-50">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-5 h-5 text-blue-500" />
                    <h2 className="font-semibold text-gray-800">Chat with Dr. Saikrishna</h2>
                  </div>
                </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.map((message) => (
                  <ChatMessage key={message.id} message={message} />
                ))}
                {loading && (
                  <div className="flex gap-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <Loader2 className="w-5 h-5 text-white animate-spin" />
                    </div>
                    <div className="bg-gray-100 rounded-2xl px-4 py-3">
                      <p className="text-sm text-gray-600">Dr. Saikrishna is thinking...</p>
                    </div>
                  </div>
                )}
                {isListening && (
                  <div className="flex gap-3 justify-end">
                    <div className="bg-blue-500 text-white rounded-2xl px-4 py-3 flex items-center gap-2">
                      <Mic className="w-5 h-5 animate-pulse" />
                      <p className="text-sm">Listening...</p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="border-t border-gray-200 p-4 bg-gray-50">
                {messages.length <= 1 && !showTextInput && (
                  <div className="mb-4">
                    <p className="text-sm text-gray-600 mb-3 font-medium">Quick Actions:</p>
                    <QuickActionButtons onActionClick={handleQuickAction} disabled={loading} />
                  </div>
                )}

                <div className="flex flex-col gap-3">
                  <div className="flex gap-3 items-center">
                    <button
                      onClick={toggleVoiceInput}
                      disabled={loading || doctorSpeaking}
                      className={`flex-1 px-6 py-4 rounded-lg font-medium transition-all flex items-center justify-center gap-3 ${
                        isListening
                          ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                          : 'bg-blue-500 hover:bg-blue-600 text-white disabled:bg-gray-300'
                      } disabled:cursor-not-allowed shadow-lg`}
                    >
                      {isListening ? (
                        <>
                          <MicOff className="w-6 h-6" />
                          <span>Stop Listening</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-6 h-6" />
                          <span>Tap to Speak</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => setShowTextInput(!showTextInput)}
                      className="p-4 rounded-lg border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-colors"
                      title={showTextInput ? "Hide keyboard" : "Show keyboard"}
                    >
                      {showTextInput ? <X className="w-6 h-6" /> : <Keyboard className="w-6 h-6" />}
                    </button>
                  </div>

                  {showTextInput && (
                    <div className="flex gap-3 animate-in slide-in-from-bottom-4 duration-300">
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder="Type your symptoms..."
                        disabled={loading}
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                        autoFocus
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={loading || !inputValue.trim()}
                        className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                      >
                        {loading ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            Send
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
              </div>

              <footer className="text-center py-4">
                <p className="text-xs text-gray-500">
                  Dr. Saikrishna Virtual Medical Assistant • For emergencies, dial 911
                </p>
              </footer>
            </main>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
