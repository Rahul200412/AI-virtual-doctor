/*
  # Allow service role to manage intents

  1. Changes
    - Add policy to allow service_role to insert, update, and delete intents
    - This allows training scripts to populate the database
*/

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Only authenticated users can insert intents" ON intents;
DROP POLICY IF EXISTS "Only authenticated users can update intents" ON intents;
DROP POLICY IF EXISTS "Only authenticated users can delete intents" ON intents;

-- Allow anon role to insert for training purposes (temporary, for development)
CREATE POLICY "Allow inserts for training"
  ON intents
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow updates for training"
  ON intents
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow deletes for training"
  ON intents
  FOR DELETE
  TO anon, authenticated
  USING (true);
