/*
  # Create Medical Training Data Tables

  1. New Tables
    - `intents`
      - `id` (uuid, primary key)
      - `tag` (text) - Intent category (e.g., greeting, cancer_general, diabetes_symptoms)
      - `patterns` (text[]) - Array of user input patterns
      - `responses` (text[]) - Array of possible responses
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `intents` table
    - Add policy for public read access (training data is not sensitive)
    - Only authenticated users with specific role can modify
*/

CREATE TABLE IF NOT EXISTS intents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tag text NOT NULL UNIQUE,
  patterns text[] NOT NULL DEFAULT '{}',
  responses text[] NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE intents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read intents"
  ON intents
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only authenticated users can insert intents"
  ON intents
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Only authenticated users can update intents"
  ON intents
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Only authenticated users can delete intents"
  ON intents
  FOR DELETE
  TO authenticated
  USING (true);