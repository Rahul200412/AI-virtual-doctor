import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface BioASQAnswer {
  text: string;
  answer_start: number;
}

interface BioASQQA {
  id: string;
  question: string;
  answers: BioASQAnswer[];
}

interface BioASQParagraph {
  qas: BioASQQA[];
  context: string;
}

interface BioASQData {
  paragraphs: BioASQParagraph[];
}

interface BioASQDataset {
  data: BioASQData[];
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Read the dataset file
    const datasetPath = '/tmp/cc-agent/59560731/project/data/BioASQ-train-factoid-6b-full-annotated.json';
    const datasetText = await Deno.readTextFile(datasetPath);
    const dataset: BioASQDataset = JSON.parse(datasetText);

    // Group questions by topic to create intents
    const intentMap = new Map<string, { patterns: Set<string>; responses: Set<string> }>();

    let processedCount = 0;
    const maxToProcess = 500; // Limit to avoid timeout

    for (const item of dataset.data) {
      if (processedCount >= maxToProcess) break;

      for (const paragraph of item.paragraphs) {
        for (const qa of paragraph.qas) {
          // Extract keywords from question to create tag
          const questionLower = qa.question.toLowerCase();
          const keywords = questionLower
            .replace(/[^a-z0-9\s]/g, '')
            .split(/\s+/)
            .filter(w => w.length > 3 && !['what', 'which', 'when', 'where', 'name', 'list'].includes(w));

          const tag = keywords.slice(0, 2).join('_') || 'medical_general';

          if (!intentMap.has(tag)) {
            intentMap.set(tag, { patterns: new Set(), responses: new Set() });
          }

          const intent = intentMap.get(tag)!;
          intent.patterns.add(qa.question);

          // Add answers as responses
          for (const answer of qa.answers) {
            if (answer.text) {
              intent.responses.add(answer.text);
            }
          }

          processedCount++;
          if (processedCount >= maxToProcess) break;
        }
        if (processedCount >= maxToProcess) break;
      }
    }

    // Insert intents into database
    const intentsToInsert = [];
    for (const [tag, data] of intentMap.entries()) {
      if (data.patterns.size > 0 && data.responses.size > 0) {
        intentsToInsert.push({
          tag,
          patterns: Array.from(data.patterns).slice(0, 20), // Limit patterns
          responses: Array.from(data.responses).slice(0, 10), // Limit responses
        });
      }
    }

    // Clear existing intents and insert new ones
    await supabase.from('intents').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    
    const { error: insertError } = await supabase
      .from('intents')
      .insert(intentsToInsert);

    if (insertError) {
      throw insertError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Successfully trained ${intentsToInsert.length} intents from ${processedCount} QA pairs`,
        intents: intentsToInsert.length,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error training dataset:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});