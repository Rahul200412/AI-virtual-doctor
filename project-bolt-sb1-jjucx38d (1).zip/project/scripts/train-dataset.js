import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import { config } from 'dotenv';

config();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function trainDataset() {
  try {
    console.log('Reading dataset...');
    const datasetPath = './data/BioASQ-train-factoid-6b-full-annotated.json';
    const datasetText = fs.readFileSync(datasetPath, 'utf-8');
    const dataset = JSON.parse(datasetText);

    console.log('Processing questions and answers...');

    // Group questions by topic to create intents
    const intentMap = new Map();

    let processedCount = 0;
    const maxToProcess = 1000; // Process first 1000 QA pairs

    for (const item of dataset.data) {
      if (processedCount >= maxToProcess) break;

      for (const paragraph of item.paragraphs) {
        for (const qa of paragraph.qas) {
          // Extract keywords from question to create tag
          const questionLower = qa.question.toLowerCase();
          const keywords = questionLower
            .replace(/[^a-z0-9\s]/g, '')
            .split(/\s+/)
            .filter(w => w.length > 3 && !['what', 'which', 'when', 'where', 'name', 'list', 'does', 'have', 'that', 'this', 'with', 'from', 'about'].includes(w));

          // Create a tag from the first 1-2 significant keywords
          let tag = keywords.slice(0, 2).join('_');
          if (!tag || tag.length < 3) {
            tag = 'medical_general';
          }

          if (!intentMap.has(tag)) {
            intentMap.set(tag, { patterns: new Set(), responses: new Set() });
          }

          const intent = intentMap.get(tag);
          intent.patterns.add(qa.question);

          // Add answers as responses with context
          for (const answer of qa.answers) {
            if (answer.text && answer.text.length > 2) {
              // Create a more informative response using the context
              const contextSnippet = paragraph.context.substring(
                Math.max(0, answer.answer_start - 50),
                Math.min(paragraph.context.length, answer.answer_start + answer.text.length + 100)
              ).trim();

              intent.responses.add(answer.text);
            }
          }

          processedCount++;
          if (processedCount >= maxToProcess) break;
        }
        if (processedCount >= maxToProcess) break;
      }
    }

    console.log(`Processed ${processedCount} QA pairs into ${intentMap.size} intents`);

    // Prepare intents for database insertion
    const intentsToInsert = [];
    for (const [tag, data] of intentMap.entries()) {
      if (data.patterns.size > 0 && data.responses.size > 0) {
        intentsToInsert.push({
          tag,
          patterns: Array.from(data.patterns).slice(0, 15), // Limit to 15 patterns per intent
          responses: Array.from(data.responses).slice(0, 8), // Limit to 8 responses per intent
        });
      }
    }

    console.log(`Inserting ${intentsToInsert.length} intents into database...`);

    // Clear existing medical intents (keep greeting and other custom intents)
    console.log('Clearing old medical intents...');
    const { error: deleteError } = await supabase
      .from('intents')
      .delete()
      .neq('tag', 'greeting');

    if (deleteError) {
      console.error('Error clearing old intents:', deleteError);
    }

    // Insert in batches to avoid payload size issues
    const batchSize = 50;
    for (let i = 0; i < intentsToInsert.length; i += batchSize) {
      const batch = intentsToInsert.slice(i, i + batchSize);
      const { error: insertError } = await supabase
        .from('intents')
        .insert(batch);

      if (insertError) {
        console.error(`Error inserting batch ${i / batchSize + 1}:`, insertError);
      } else {
        console.log(`Inserted batch ${i / batchSize + 1} (${batch.length} intents)`);
      }
    }

    console.log('✅ Dataset training completed successfully!');
    console.log(`Total intents in database: ${intentsToInsert.length}`);

  } catch (error) {
    console.error('❌ Error training dataset:', error);
    process.exit(1);
  }
}

trainDataset();
